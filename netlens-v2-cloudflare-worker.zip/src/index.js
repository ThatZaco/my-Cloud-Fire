const esc = (v) => String(v ?? "").replace(/[&<>"']/g, s => ({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
}[s]));

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (request.method !== "GET" && request.method !== "HEAD") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    if (url.pathname === "/api/ip") {
      const cf = request.cf || {};
      return Response.json({
        ip: request.headers.get("CF-Connecting-IP") || "",
        country: request.headers.get("CF-IPCountry") || "",
        city: cf.city || "",
        region: cf.region || "",
        postalCode: cf.postalCode || "",
        timezone: cf.timezone || "",
        continent: cf.continent || "",
        asn: cf.asn || null,
        organization: cf.asOrganization || "",
        colo: cf.colo || "",
        latitude: cf.latitude || "",
        longitude: cf.longitude || "",
        httpProtocol: cf.httpProtocol || "",
        tlsVersion: cf.tlsVersion || "",
        tlsCipher: cf.tlsCipher || "",
        userAgent: request.headers.get("User-Agent") || "",
        language: request.headers.get("Accept-Language") || "",
        referer: request.headers.get("Referer") || ""
      }, { headers: { "Cache-Control": "no-store" }});
    }

    if (url.pathname === "/api/headers") {
      const headers = {};
      for (const [k,v] of request.headers) headers[k] = v;
      return Response.json(headers, { headers: { "Cache-Control": "no-store" }});
    }

    if (url.pathname === "/health") {
      return new Response("OK", { headers: {"Content-Type":"text/plain; charset=UTF-8"}});
    }

    return new Response(page(), {
      headers: {"Content-Type":"text/html; charset=UTF-8"}
    });
  }
};

function page() {
return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0b1020">
<meta name="description" content="Cloudflare Worker 网络信息检测工具 V2">
<title>NetLens · 网络信息检测</title>
<style>
:root{--bg:#070b16;--panel:#101729;--panel2:#151d31;--text:#eef4ff;--muted:#91a0ba;--line:#24304a;--accent:#67e8f9;--accent2:#818cf8;--ok:#4ade80}
*{box-sizing:border-box}
body{margin:0;background:radial-gradient(circle at 20% 0%,#182b50 0,#070b16 38%,#070b16 100%);color:var(--text);font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.wrap{max-width:1120px;margin:auto;padding:26px 18px 60px}
.nav{display:flex;justify-content:space-between;align-items:center;margin-bottom:28px}
.brand{font-weight:800;letter-spacing:.4px;font-size:20px}.brand span{color:var(--accent)}
.badge{font-size:12px;padding:7px 10px;border:1px solid var(--line);border-radius:999px;color:var(--muted);background:#0c1221}
.hero{position:relative;overflow:hidden;padding:38px;border:1px solid var(--line);border-radius:28px;background:linear-gradient(135deg,rgba(103,232,249,.09),rgba(129,140,248,.08));box-shadow:0 20px 60px rgba(0,0,0,.25)}
.hero:after{content:"";position:absolute;width:260px;height:260px;border-radius:50%;right:-100px;top:-120px;background:rgba(103,232,249,.13);filter:blur(20px)}
h1{font-size:clamp(32px,6vw,58px);line-height:1.02;margin:0 0 14px;max-width:720px}
.hero p{color:var(--muted);font-size:16px;max-width:680px;margin:0;line-height:1.7}
.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}
button{border:0;border-radius:12px;padding:12px 17px;font-weight:700;cursor:pointer;background:linear-gradient(135deg,var(--accent2),var(--accent));color:#07101d}
button.secondary{background:var(--panel2);border:1px solid var(--line);color:var(--text)}
.status{margin-top:16px;color:var(--muted);font-size:13px}.dot{display:inline-block;width:8px;height:8px;background:var(--ok);border-radius:50%;margin-right:7px}
.section{margin-top:20px}.section-title{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
h2{font-size:17px;margin:0}.hint{font-size:12px;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.card{background:rgba(16,23,41,.86);border:1px solid var(--line);border-radius:17px;padding:17px;min-height:110px;backdrop-filter:blur(12px)}
.label{font-size:12px;color:var(--muted);margin-bottom:9px}.value{font-size:18px;font-weight:750;word-break:break-word}.small{font-size:13px;color:#b8c4d8;margin-top:6px;word-break:break-word}
.panel{background:rgba(16,23,41,.9);border:1px solid var(--line);border-radius:17px;padding:18px}
pre{margin:0;max-height:430px;overflow:auto;white-space:pre-wrap;word-break:break-word;color:#cfe2ff;background:#080d19;border-radius:12px;padding:15px;font-size:12px;line-height:1.6}
footer{text-align:center;color:#64728a;font-size:12px;margin-top:28px}
@media(max-width:850px){.grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:520px){.wrap{padding:16px 12px 45px}.hero{padding:25px 20px;border-radius:22px}.grid{grid-template-columns:1fr}.nav{margin-bottom:18px}.card{min-height:auto}}
</style>
</head>
<body>
<div class="wrap">
<div class="nav"><div class="brand">Net<span>Lens</span></div><div class="badge">Cloudflare Worker · V2</div></div>

<section class="hero">
<h1>你的网络，<br>一眼看清。</h1>
<p>快速查看公网 IP、Cloudflare 节点、协议、TLS、地理位置、User-Agent 与请求 Headers。无需 VPS，直接运行在 Cloudflare Workers。</p>
<div class="actions">
<button onclick="loadAll()">↻ 重新检测</button>
<button class="secondary" onclick="copyIP()">复制 IP</button>
</div>
<div class="status"><span class="dot"></span><span id="status">正在检测网络信息…</span></div>
</section>

<section class="section">
<div class="section-title"><h2>核心信息</h2><span class="hint">实时请求数据</span></div>
<div id="cards" class="grid"></div>
</section>

<section class="section">
<div class="section-title"><h2>请求 Headers</h2><span class="hint">当前访问请求</span></div>
<div class="panel"><pre id="headers">正在读取…</pre></div>
</section>

<footer>NetLens V2 · Powered by Cloudflare Workers</footer>
</div>

<script>
let currentIP="";
const fields=[
["公网 IP","ip"],["国家 / 地区","country"],["城市","city"],["地区","region"],
["时区","timezone"],["ASN","asn"],["运营商","organization"],["CF 节点","colo"],
["HTTP 协议","httpProtocol"],["TLS 版本","tlsVersion"],["TLS Cipher","tlsCipher"],
["经纬度",x=>x.latitude&&x.longitude?x.latitude+", "+x.longitude:""],
["Postal Code","postalCode"],["User-Agent","userAgent"]
];
async function loadAll(){
  document.getElementById("status").textContent="正在检测网络信息…";
  try{
    const [info,headers]=await Promise.all([
      fetch("/api/ip",{cache:"no-store"}).then(r=>r.json()),
      fetch("/api/headers",{cache:"no-store"}).then(r=>r.json())
    ]);
    currentIP=info.ip||"";
    document.getElementById("cards").innerHTML=fields.map(([label,key])=>{
      const value=typeof key==="function"?key(info):info[key];
      return '<div class="card"><div class="label">'+esc(label)+'</div><div class="value">'+esc(value||"-")+'</div></div>';
    }).join("");
    document.getElementById("headers").textContent=JSON.stringify(headers,null,2);
    document.getElementById("status").textContent="检测完成 · 数据来自当前请求";
  }catch(e){
    document.getElementById("status").textContent="检测失败："+e.message;
  }
}
async function copyIP(){
  if(!currentIP)return;
  try{await navigator.clipboard.writeText(currentIP);document.getElementById("status").textContent="IP 已复制："+currentIP}
  catch(e){document.getElementById("status").textContent="复制失败，请手动复制"}
}
function esc(v){return String(v??"").replace(/[&<>"']/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[s]))}
loadAll();
</script>
</body>
</html>`;
}
