# NetLens V2 — Cloudflare Worker 网络信息工具站

一个无需 VPS、无需数据库的漂亮网络信息检测站，直接运行在 Cloudflare Workers。

## V2 功能

- 响应式手机 / PC UI
- 深色科技风界面
- 公网 IP
- 国家/地区
- 城市 / 地区
- 时区
- ASN
- 运营商
- Cloudflare 数据中心节点
- HTTP 协议
- TLS 版本 / Cipher
- 经纬度
- Postal Code
- User-Agent
- 当前请求 Headers
- 一键重新检测
- 一键复制 IP
- `/api/ip` JSON API
- `/api/headers` JSON API
- `/health` 健康检查

## Dashboard 部署

1. 登录 Cloudflare。
2. 打开 Workers & Pages。
3. 创建 Worker。
4. 将 `src/index.js` 的全部内容复制到编辑器。
5. 点击 Deploy。
6. 使用生成的 `workers.dev` 地址访问。
7. 如果要绑定自己的域名：Worker → Settings → Domains & Routes → Add Custom Domain。

## Wrangler 部署

项目已经提供 `wrangler.toml`。

```bash
npm install
npx wrangler login
npx wrangler deploy
```

## API

- `/api/ip`
- `/api/headers`
- `/health`

## 说明

部分地理位置、ASN、Cloudflare 节点和 TLS 信息来自 Cloudflare Worker 的 `request.cf` 以及 Cloudflare 请求头，因此具体字段是否有值取决于 Cloudflare 当前提供的信息。

本项目不存储访问者信息。
